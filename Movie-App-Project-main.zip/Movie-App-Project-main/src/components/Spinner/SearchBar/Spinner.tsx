import styles from "../SearchBar/Spinner.module.scss";

const Spinner = () => {
  return <span className={styles.spinner}></span>;
};

export default Spinner;
